#include <iostream>           // For cerr and cout


#include "TapSignOn.h"




using namespace std;


int main()
{


   /* CiniRW *iReader = new CiniRW("setting.ini");
    iReader->getSectionName("SECTION");
    iReader->getSectionData();

    cout << iReader->getKeyValue("ID") << endl;*/



    //SockConn.BindConnection1();


    TapSignOn _obj;

   _obj.Init();

//    ClientHandler _obj1;



   /* PFHolder _pf;

    memset(&_pf,0,sizeof(_pf));
    _pf.PF=10;
    _pf.CID=2;
    _pf.HashKey =65421;
    _pf._size=136;
    _FillData.BidQueue(_pf);
*/


//// cout << sizeof(C_SignIn) <<endl;

int iinp;
cin >> iinp;

		return 0;
}
